Memo Printer 80mm — Preview/Text Rendering Fix

This version fixes the blank Preview / Saved Memo rendering by bundling a Bengali-capable Noto Sans Bengali font and using a density-independent memo template resource.

Main fixes:
- Preview now renders memo number, next-day date, customer, address, products, amounts and total onto the original 80mm memo image.
- Saved Memo thumbnails/View use the same renderer.
- Original memo template is kept unchanged.
- memo_template.jpg is in drawable-nodpi so Android density does not alter its base size.
- Bengali regular/bold fonts are bundled inside the APK.
