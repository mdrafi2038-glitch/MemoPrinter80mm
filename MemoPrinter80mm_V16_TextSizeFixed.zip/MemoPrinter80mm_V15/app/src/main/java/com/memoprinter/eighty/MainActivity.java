package com.memoprinter.eighty;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int BLUE=Color.rgb(37,99,235), BLUE_DARK=Color.rgb(30,64,175), TEXT=Color.rgb(15,23,42), MUTED=Color.rgb(100,116,139), BG=Color.rgb(246,248,252), WHITE=Color.WHITE, BORDER=Color.rgb(226,232,240), GREEN=Color.rgb(16,185,129), RED=Color.rgb(239,68,68);
    static final String SPP="00001101-0000-1000-8000-00805F9B34FB";
    final ArrayList<Item> items=new ArrayList<>();
    final LinkedHashMap<String,Double> prices=new LinkedHashMap<>();
    final ArrayList<Memo> history=new ArrayList<>();
    BluetoothAdapter bt; BluetoothSocket socket; String printerName="", printerMac="";
    int memoNo=1;
    String currentScreen="home";
    final ArrayDeque<String> backStack=new ArrayDeque<>();
    boolean restoringScreen=false;
    EditText customer,address; TextView totalView, countView; Switch autoPrint; LinearLayout productList,root; ImageView livePreview; Typeface memoRegular, memoBold;

    static class Item { String name,qty,price,amount; Item(String n,String q,String p,String a){name=n;qty=q;price=p;amount=a;} }
    static class Memo { int no; String date,name,address; ArrayList<Item> items=new ArrayList<>(); double total; }

    @Override public void onCreate(Bundle b){ super.onCreate(b);
        // Android 15 enforces edge-to-edge for modern target SDKs. Draw behind the
        // system bars, then apply their real insets to the root container (SafeArea).
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
            getWindow().setStatusBarContrastEnforced(false);
            getWindow().setNavigationBarContrastEnforced(false);
        } else {
            getWindow().setStatusBarColor(WHITE);
            getWindow().setNavigationBarColor(BG);
        }
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if(Build.VERSION.SDK_INT>=23) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        try { memoRegular=Typeface.createFromAsset(getAssets(),"NotoSansBengali-Regular.ttf"); } catch(Throwable ignored) { memoRegular=Typeface.create("sans-serif",Typeface.NORMAL); }
        try { memoBold=Typeface.createFromAsset(getAssets(),"NotoSansBengali-Bold.ttf"); } catch(Throwable ignored) { memoBold=Typeface.create("sans-serif",Typeface.BOLD); }
        memoNo=getPreferences(0).getInt("memo",1); if(memoNo<1 || memoNo>999999){ memoNo=1; } loadPrices(); loadHistory(); loadPrinter(); home();
        if(Build.VERSION.SDK_INT>=33){
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::goBack);
        }
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},10);
    }

    int dp(int v){ return Math.round(v * getResources().getDisplayMetrics().density); }
    TextView tv(String s,float sp,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    GradientDrawable shape(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(Math.round(r))); return g; }
    GradientDrawable outline(int fill,int stroke,float r){ GradientDrawable g=shape(fill,r); g.setStroke(dp(1),stroke); return g; }
    View gap(int h){ Space s=new Space(this); s.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h))); return s; }
    Button action(String label){ Button b=new Button(this); b.setText(label); b.setTextSize(14); b.setTextColor(WHITE); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setBackground(shape(BLUE,18)); b.setPadding(dp(14),0,dp(14),0); return b; }
    Button lightAction(String label){ Button b=new Button(this); b.setText(label); b.setTextSize(13); b.setTextColor(BLUE_DARK); b.setAllCaps(false); b.setBackground(outline(WHITE,BORDER,16)); b.setPadding(dp(12),0,dp(12),0); return b; }
    EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16); e.setTextColor(TEXT); e.setHintTextColor(MUTED); e.setPadding(dp(15),0,dp(15),0); e.setSingleLine(true); e.setBackground(outline(WHITE,BORDER,15)); e.setMinHeight(dp(52)); return e; }
    TextView label(String s){ TextView t=tv(s,13,MUTED); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(dp(2),0,dp(2),dp(6)); return t; }
    LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(16),dp(15),dp(16),dp(15)); c.setBackground(outline(WHITE,BORDER,22)); return c; }

    void openScreen(String name){
        if(restoringScreen){ currentScreen=name; return; }
        if(!name.equals(currentScreen)) backStack.push(currentScreen);
        currentScreen=name;
    }

    @Override public void onBackPressed(){
        if(root==null){ super.onBackPressed(); return; }
        if(!backStack.isEmpty()){
            String previous=backStack.pop();
            restoringScreen=true;
            renderScreen(previous);
            restoringScreen=false;
        } else if(!"home".equals(currentScreen)){
            restoringScreen=true; home(); restoringScreen=false;
        } else {
            super.onBackPressed();
        }
    }

    void goBack(){ onBackPressed(); }

    void renderScreen(String name){
        if("newMemo".equals(name)) newMemo();
        else if("saved".equals(name)) savedMemos();
        else if("printer".equals(name)) printerScreen();
        else if("settings".equals(name)) settings();
        else home();
    }

    // Safe-area handling for modern Android / edge-to-edge devices.
    // Keep the app content below the status bar and above the navigation/gesture area.
    void applyWindowInsets(View v){
        final int left=v.getPaddingLeft();
        final int top=v.getPaddingTop();
        final int right=v.getPaddingRight();
        final int bottom=v.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(v, (view, insets) -> {
            Insets bars=insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            view.setPadding(left + bars.left, top + bars.top, right + bars.right, bottom + bars.bottom);
            return insets;
        });
        ViewCompat.requestApplyInsets(v);
    }

    void shell(String title,String subtitle,boolean back){
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(false);

        // Keep the window in the normal (non edge-to-edge) layout mode. This avoids
        // Android 15 status-bar/notch overlap while still working on older devices.
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(true);
            getWindow().setStatusBarColor(WHITE);
            getWindow().setNavigationBarColor(BG);
        }

        LinearLayout bar=new LinearLayout(this);
        bar.setTag("APP_TOOLBAR");
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8),0,dp(12),0);
        bar.setBackgroundColor(WHITE);
        bar.setMinimumHeight(dp(64));

        if(back){
            TextView x=tv("‹",36,TEXT);
            x.setGravity(Gravity.CENTER);
            x.setContentDescription("Back");
            bar.addView(x,new LinearLayout.LayoutParams(dp(48),dp(64)));
            x.setOnClickListener(v->goBack());
        }
        LinearLayout tt=new LinearLayout(this);
        tt.setOrientation(LinearLayout.VERTICAL);
        tt.setGravity(Gravity.CENTER_VERTICAL);
        TextView a=tv(title,21,TEXT);
        a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        TextView cc=tv(subtitle,12,MUTED);
        tt.addView(a,new LinearLayout.LayoutParams(-1,dp(30)));
        tt.addView(cc,new LinearLayout.LayoutParams(-1,dp(22)));
        bar.addView(tt,new LinearLayout.LayoutParams(0,dp(64),1));
        root.addView(bar,new LinearLayout.LayoutParams(-1,dp(64)));
        setContentView(root);
    }
    ScrollView scroll(){
        ScrollView s=new ScrollView(this);
        s.setFillViewport(true);
        s.setClipToPadding(false);
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16),dp(16),dp(16),dp(28));
        // MATCH_PARENT + fillViewport makes the content occupy the available height;
        // it still grows beyond the viewport when there is more content to scroll.
        s.addView(c,new ScrollView.LayoutParams(-1,-1));
        root.addView(s,new LinearLayout.LayoutParams(-1,0,1));
        return s;
    }
    LinearLayout content(ScrollView s){ return (LinearLayout)s.getChildAt(0); }
    TextView section(String s){ TextView t=tv(s,15,TEXT); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(dp(2),dp(7),dp(2),dp(8)); return t; }

    void home(){
        if(!restoringScreen){ currentScreen="home"; backStack.clear(); }
        shell("Memo Printer 80mm","বাংলা মেমো • Bluetooth Thermal Printer",false);

        ScrollView sv=new ScrollView(this);
        sv.setFillViewport(true);
        sv.setClipToPadding(false);
        sv.setBackgroundColor(BG);
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16),dp(16),dp(16),dp(20));
        sv.addView(c,new ScrollView.LayoutParams(-1,-2));
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout hero=card();
        hero.setPadding(dp(20),dp(18),dp(20),dp(16));
        hero.setBackground(shape(BLUE,24));
        TextView h=tv("মেমো টাইপ করে\nঅটো প্রিন্ট করুন",25,WHITE);
        h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        hero.addView(h,new LinearLayout.LayoutParams(-1,0,1));
        hero.addView(tv("সহজে অর্ডার লিখুন • অটো হিসাব • 80mm Print",13,0xFFE0E7FF));
        c.addView(hero);
        c.addView(gap(10));

        LinearLayout r1=new LinearLayout(this); r1.setOrientation(LinearLayout.HORIZONTAL);
        homeCard(r1,"🧾","মেমো তৈরি করুন","নতুন অর্ডার",v->newMemo());
        homeCard(r1,"📚","Saved Memos","পুরনো মেমো",v->savedMemos());
        c.addView(r1,new LinearLayout.LayoutParams(-1,dp(142)));
        c.addView(gap(10));

        LinearLayout r2=new LinearLayout(this); r2.setOrientation(LinearLayout.HORIZONTAL);
        homeCard(r2,"🖨","Bluetooth","Printer connect",v->printerScreen());
        homeCard(r2,"⚙","Settings","পণ্য ও দাম",v->settings());
        c.addView(r2,new LinearLayout.LayoutParams(-1,dp(142)));
        c.addView(gap(10));

        LinearLayout info=card();
        TextView feature=tv("✓ বাংলা সংখ্যা ও বাংলা quantity/price\n✓ Quantity × default price = amount\n✓ Original memo template + LIVE preview + bitmap print\n✓ Local saved history",13,TEXT);
        feature.setGravity(Gravity.CENTER_VERTICAL);
        info.addView(feature,new LinearLayout.LayoutParams(-1,dp(105)));
        c.addView(info);

        // On tall phones, distribute the available height instead of leaving a
        // large white block at the bottom. On short phones, normal scrolling remains.
        sv.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{
            int available=b-t-sv.getPaddingTop()-sv.getPaddingBottom();
            int used=dp(142+142+105+20+16+20+64); // content + gaps + margins
            int extra=available-used;
            if(extra>0){
                int add=extra/4;
                setHeight(hero,dp(150)+add);
                setHeight(r1,dp(142)+add);
                setHeight(r2,dp(142)+add);
                setHeight(info,dp(105)+add);
            }
        });
    }
    void setHeight(View v,int h){ ViewGroup.LayoutParams lp=v.getLayoutParams(); if(lp!=null && lp.height!=h){lp.height=h;v.setLayoutParams(lp);} }
    void homeCard(LinearLayout row,String icon,String title,String sub,View.OnClickListener click){ LinearLayout c=card(); c.setOnClickListener(click); c.setPadding(dp(14),dp(13),dp(10),dp(12)); TextView i=tv(icon,25,TEXT); i.setGravity(Gravity.CENTER_VERTICAL); c.addView(i,new LinearLayout.LayoutParams(-1,dp(35))); TextView a=tv(title,16,TEXT); a.setTypeface(Typeface.DEFAULT,Typeface.BOLD); c.addView(a); c.addView(tv(sub,12,MUTED)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); p.setMargins(0,0,dp(5),0); row.addView(c,p); }

    void newMemo(){
        boolean wasNewScreen = !"newMemo".equals(currentScreen);
        openScreen("newMemo");
        if(wasNewScreen) items.clear();
        shell("নতুন তৈরি করুন","মেমো নং "+memoLabel(memoNo)+" • পরের দিনের তারিখ",true);
        ScrollView sv=scroll(); LinearLayout c=content(sv);

        LinearLayout info=card(); info.addView(section("কাস্টমার তথ্য"));
        info.addView(label("কাস্টমারের নাম")); customer=input("কাস্টমারের নাম লিখুন"); info.addView(customer); info.addView(gap(10));
        info.addView(label("ঠিকানা")); address=input("ঠিকানা লিখুন"); address.setSingleLine(false); address.setMinLines(2); address.setGravity(Gravity.TOP); address.setPadding(dp(15),dp(12),dp(15),dp(12)); info.addView(address);
        c.addView(info); c.addView(gap(12));

        LinearLayout prod=card(); LinearLayout ph=new LinearLayout(this); ph.setGravity(Gravity.CENTER_VERTICAL); TextView st=section("পণ্য তালিকা"); ph.addView(st,new LinearLayout.LayoutParams(0,dp(40),1)); countView=tv("০ পণ্য",12,MUTED); ph.addView(countView); prod.addView(ph);
        productList=new LinearLayout(this); productList.setOrientation(LinearLayout.VERTICAL); prod.addView(productList);
        Button add=action("＋  পণ্য যোগ করুন"); add.setOnClickListener(v->addProductDialog(-1)); prod.addView(gap(10)); prod.addView(add); c.addView(prod); c.addView(gap(12));

        LinearLayout sum=card(); sum.setPadding(dp(18),dp(15),dp(18),dp(15)); totalView=tv("মোট টাকা: ৳০",21,TEXT); totalView.setGravity(Gravity.RIGHT); totalView.setTypeface(Typeface.DEFAULT,Typeface.BOLD); sum.addView(totalView);
        autoPrint=new Switch(this); autoPrint.setText("সেভ করলে Auto Print"); autoPrint.setTextSize(14); autoPrint.setTextColor(TEXT); sum.addView(autoPrint); c.addView(sum); c.addView(gap(12));

        LinearLayout buttons=new LinearLayout(this);
        Button save=action("💾  Save Memo"); save.setOnClickListener(v->saveAndMaybePrint());
        buttons.addView(save,new LinearLayout.LayoutParams(0,dp(54),1));
        Button previewBtn=lightAction("👁  Preview"); previewBtn.setOnClickListener(v->previewMemo());
        LinearLayout.LayoutParams previewLp=new LinearLayout.LayoutParams(0,dp(54),1); previewLp.setMargins(dp(8),0,0,0);
        buttons.addView(previewBtn,previewLp);
        c.addView(buttons); c.addView(gap(12));

        LinearLayout liveCard=card(); TextView liveTitle=tv("LIVE PREVIEW • 80mm",15,TEXT); liveTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD); liveCard.addView(liveTitle);
        livePreview=new ImageView(this);
        livePreview.setAdjustViewBounds(true);
        livePreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        livePreview.setBackgroundColor(WHITE);
        livePreview.setContentDescription("Live memo preview");
        livePreview.setOnClickListener(v->previewMemo());
        LinearLayout.LayoutParams liveLp=new LinearLayout.LayoutParams(-1,dp(620));
        liveLp.setMargins(0,dp(8),0,0);
        liveCard.addView(livePreview,liveLp);
        c.addView(liveCard);
        customer.addTextChangedListener(simpleWatcher()); address.addTextChangedListener(simpleWatcher());
        refreshProducts(); updateLivePreview();
    }
    android.text.TextWatcher simpleWatcher(){ return new android.text.TextWatcher(){ public void beforeTextChanged(CharSequence s,int a,int b,int c){} public void onTextChanged(CharSequence s,int a,int b,int c){updateLivePreview(); if(livePreview!=null) livePreview.post(()->updateLivePreview());} public void afterTextChanged(Editable e){} }; }
    void updateLivePreview(){
        if(livePreview==null) return;
        livePreview.post(() -> {
            try {
                Memo m=readMemo();
                Bitmap bm=renderMemo(m);
                livePreview.setImageBitmap(bm);
                livePreview.setVisibility(View.VISIBLE);
                livePreview.invalidate();
            } catch(Throwable e) {
                livePreview.setImageDrawable(null);
                livePreview.setContentDescription("Preview render error");
                Toast.makeText(MainActivity.this, "Preview render error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    void addProductDialog(final int editIndex){
        final LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(4),dp(2),dp(4),dp(2));
        final EditText n=input("পণ্যের নাম"); final EditText q=input("পরিমাণ — ২ / 2"); final EditText p=input("প্রতি পিস দাম — ২৫ / 25");
        q.setInputType(android.text.InputType.TYPE_CLASS_TEXT); p.setInputType(android.text.InputType.TYPE_CLASS_TEXT); l.addView(label("পণ্য নাম")); l.addView(n); l.addView(gap(8)); l.addView(label("পরিমাণ (pcs)")); l.addView(q); l.addView(gap(8)); l.addView(label("প্রতি পিস দাম")); l.addView(p); l.addView(gap(8));
        TextView calc=tv("Amount: ৳০",17,BLUE); calc.setTypeface(Typeface.DEFAULT,Typeface.BOLD); calc.setPadding(dp(5),dp(5),dp(5),dp(8)); l.addView(calc);
        if(editIndex>=0 && editIndex<items.size()){ Item x=items.get(editIndex); n.setText(x.name); q.setText(x.qty); p.setText(x.price); }
        n.setOnFocusChangeListener((v,has)->{ if(!has){Double d=findPrice(n.getText().toString().trim()); if(d!=null && p.getText().toString().trim().isEmpty()) p.setText(bn(formatNumber(d))); updateCalc(q,p,calc);} });
        n.addTextChangedListener(watcher(q,p,calc)); q.addTextChangedListener(watcher(q,p,calc)); p.addTextChangedListener(watcher(q,p,calc)); updateCalc(q,p,calc);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(editIndex>=0?"পণ্য পরিবর্তন":"পণ্য যোগ করুন").setView(l).setNegativeButton("বাতিল",null).setPositiveButton(editIndex>=0?"আপডেট":"যোগ করুন",null).create();
        dlg.setOnShowListener(x->{dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String name=n.getText().toString().trim(); double qty=num(q.getText().toString()), price=num(p.getText().toString()); if(name.isEmpty()){n.setError("পণ্যের নাম দিন");return;} if(qty<=0){q.setError("পরিমাণ দিন");return;} if(price<=0){Double d=findPrice(name); if(d!=null)price=d;} if(price<=0){p.setError("দাম দিন");return;} Item item=new Item(name,bn(formatNumber(qty)),bn(formatNumber(price)),bn(formatNumber(qty*price))); if(editIndex>=0)items.set(editIndex,item);else items.add(item); refreshProducts(); dlg.dismiss();});});
        dlg.getWindow(); dlg.show();
    }
    Double findPrice(String name){ if(name==null)return null; for(String k:prices.keySet())if(k.equalsIgnoreCase(name.trim()))return prices.get(k); return null; }
    android.text.TextWatcher watcher(EditText q,EditText p,TextView c){ return new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int d){} public void onTextChanged(CharSequence s,int a,int b,int d){updateCalc(q,p,c);} public void afterTextChanged(Editable e){}}; }
    void updateCalc(EditText q,EditText p,TextView c){ c.setText("Amount: ৳"+bn(formatNumber(num(q.getText().toString())*num(p.getText().toString())))); }

    void refreshProducts(){
        if(productList==null)return; productList.removeAllViews(); double sum=0;
        if(items.isEmpty()){ TextView e=tv("এখনও কোনো পণ্য যোগ করা হয়নি\n＋ পণ্য যোগ করুন চাপুন",14,MUTED); e.setGravity(Gravity.CENTER); e.setPadding(dp(5),dp(22),dp(5),dp(22)); productList.addView(e); }
        for(int i=0;i<items.size();i++){ final int idx=i; Item x=items.get(i); sum+=num(x.amount);
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(4),dp(8),0,dp(8)); row.setBackground(outline(0xFFF8FAFC,Color.TRANSPARENT,14));
            LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); TextView nm=tv(x.name,15,TEXT); nm.setTypeface(Typeface.DEFAULT,Typeface.BOLD); info.addView(nm); info.addView(tv("পরিমাণ: "+x.qty+"   •   প্রতি পিস: ৳"+x.price,12,MUTED));
            TextView am=tv("৳"+x.amount,15,TEXT); am.setTypeface(Typeface.DEFAULT,Typeface.BOLD); am.setGravity(Gravity.RIGHT); TextView edit=tv("✎",21,BLUE); edit.setGravity(Gravity.CENTER); TextView del=tv("×",25,RED); del.setGravity(Gravity.CENTER);
            row.addView(info,new LinearLayout.LayoutParams(0,dp(60),1)); row.addView(am,new LinearLayout.LayoutParams(dp(78),dp(60))); row.addView(edit,new LinearLayout.LayoutParams(dp(38),dp(60))); row.addView(del,new LinearLayout.LayoutParams(dp(36),dp(60)));
            edit.setOnClickListener(v->addProductDialog(idx)); del.setOnClickListener(v->{items.remove(idx);refreshProducts();}); productList.addView(row); if(i<items.size()-1)productList.addView(gap(2));
        }
        if(totalView!=null)totalView.setText("মোট টাকা: ৳"+bn(formatNumber(sum))); if(countView!=null)countView.setText(bn(String.valueOf(items.size()))+" পণ্য"); updateLivePreview(); if(livePreview!=null)livePreview.post(()->updateLivePreview());
    }

    Memo readMemo(){ Memo m=new Memo(); m.no=memoNo; m.date=memoDate(); m.name=customer==null?"":customer.getText().toString().trim(); m.address=address==null?"":address.getText().toString().trim(); for(Item x:items)m.items.add(new Item(x.name,x.qty,x.price,x.amount)); m.total=total(); return m; }
    void previewMemo(){
        if(items.isEmpty()){toast("কমপক্ষে ১টি পণ্য যোগ করুন");return;}
        Memo m=readMemo();
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(8),dp(8),dp(8),dp(8));
        ImageView image=new ImageView(this); image.setImageBitmap(renderMemo(m)); image.setAdjustViewBounds(true); image.setScaleType(ImageView.ScaleType.FIT_CENTER); image.setBackgroundColor(WHITE); box.addView(image,new LinearLayout.LayoutParams(-1,-2));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Print Preview • 80mm").setView(box).setNegativeButton("Close",null).setPositiveButton("🖨 Print",(d,w)->printMemo(m)).create(); dlg.show();
    }
    void saveAndMaybePrint(){ if(items.isEmpty()){toast("কমপক্ষে ১টি পণ্য যোগ করুন");return;} Memo m=readMemo(); persistMemo(m); if(autoPrint!=null&&autoPrint.isChecked())printMemo(m);else toast("মেমো "+memoLabel(m.no)+" সেভ হয়েছে ✓"); }
    void persistMemo(Memo m){ boolean isNew=(m.no==memoNo); saveMemo(m); if(isNew){getPreferences(0).edit().putInt("memo",memoNo+1).apply();memoNo++;} }
    void saveMemo(Memo m){ history.removeIf(x->x.no==m.no); history.add(0,m); while(history.size()>100)history.remove(history.size()-1); saveHistory(); }

    Bitmap renderMemo(Memo m){
        Bitmap src=BitmapFactory.decodeResource(getResources(), R.drawable.memo_template);
        if(src==null) throw new IllegalStateException("Memo template could not be loaded");
        final int w=576;
        final float sx=w/(float)src.getWidth();
        final int h=Math.round(src.getHeight()*sx);
        Bitmap b=Bitmap.createScaledBitmap(src,w,h,true).copy(Bitmap.Config.ARGB_8888,true);
        Canvas c=new Canvas(b);

        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setColor(Color.BLACK);
        p.setTypeface(memoRegular!=null?memoRegular:Typeface.create("sans-serif",Typeface.NORMAL));
        p.setStyle(Paint.Style.FILL);

        // Header values
        p.setTextSize(25*sx);
        draw(c,p,bn(String.valueOf(m.no)),260*sx,151*sx,Paint.Align.CENTER);
        p.setTextSize(24*sx);
        draw(c,p,bn(m.date),482*sx,151*sx,Paint.Align.CENTER);

        // Customer information
        p.setTextSize(23*sx);
        draw(c,p,fit(m.name,275*sx,p),105*sx,217*sx,Paint.Align.LEFT);
        draw(c,p,fit(m.address,275*sx,p),105*sx,280*sx,Paint.Align.LEFT);

        // Product rows
        float[] rows={405,466,527,587,647,707,768,828,889,949,1010};
        p.setTextSize(22*sx);
        for(int i=0;i<m.items.size() && i<rows.length;i++){
            Item x=m.items.get(i);
            float y=rows[i]*sx;
            draw(c,p,fit(x.name,265*sx,p),18*sx,y,Paint.Align.LEFT);
            draw(c,p,fit(x.qty,70*sx,p),352*sx,y,Paint.Align.CENTER);
            draw(c,p,fit(x.amount,145*sx,p),486*sx,y,Paint.Align.CENTER);
        }

        // Total just below the table, before the signature boxes.
        p.setTypeface(memoBold!=null?memoBold:Typeface.create("sans-serif",Typeface.BOLD));
        p.setTextSize(23*sx);
        draw(c,p,"মোট: ৳"+bn(formatNumber(m.total)),288*sx,1085*sx,Paint.Align.CENTER);
        return b;
    }
    void draw(Canvas c,Paint p,String s,float x,float y,Paint.Align a){p.setTextAlign(a);c.drawText(s==null?"":s,x,y,p);}
    String fit(String s,float max,Paint p){if(s==null)return "";if(p.measureText(s)<=max)return s;String z=s;while(z.length()>1&&p.measureText(z+"…")>max)z=z.substring(0,z.length()-1);return z+"…";}

    void printerScreen(){ openScreen("printer"); shell("Bluetooth Printer","80mm ESC/POS • Classic SPP",true); ScrollView sv=scroll(); LinearLayout c=content(sv); LinearLayout st=card(); st.addView(tv("CURRENT PRINTER",11,MUTED)); TextView name=tv(printerName.isEmpty()?"কোনো printer connect নেই":printerName,18,TEXT);name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);st.addView(name);if(!printerMac.isEmpty())st.addView(tv(printerMac,12,MUTED));c.addView(st);c.addView(gap(12));Button choose=action("🔵  Paired Bluetooth Printers");choose.setOnClickListener(v->choosePrinter());c.addView(choose);c.addView(gap(9));Button test=lightAction("🖨  Test Print");test.setOnClickListener(v->printMemo(sampleTestMemo()));c.addView(test);c.addView(gap(12));LinearLayout help=card();help.addView(tv("প্রথমবার: Phone Settings → Bluetooth → printer pair করুন।\nতারপর এখানে printer select করুন।",13,TEXT));c.addView(help); }
    void choosePrinter(){ if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},11);return;}bt=BluetoothAdapter.getDefaultAdapter();if(bt==null){toast("এই ফোনে Bluetooth নেই");return;}if(!bt.isEnabled()){toast("আগে Bluetooth চালু করুন");return;}final ArrayList<BluetoothDevice> ds=new ArrayList<>(bt.getBondedDevices());if(ds.isEmpty()){toast("Phone Settings থেকে printer pair করুন");return;}String[] names=new String[ds.size()];for(int i=0;i<ds.size();i++){String n=ds.get(i).getName();names[i]=(n==null?"Bluetooth device":n)+"\n"+ds.get(i).getAddress();}new AlertDialog.Builder(this).setTitle("Paired Bluetooth Devices").setItems(names,(d,w)->connect(ds.get(w))).setNegativeButton("Cancel",null).show(); }
    void connect(BluetoothDevice d){ new Thread(()->{try{if(socket!=null)try{socket.close();}catch(Exception ignored){}socket=d.createRfcommSocketToServiceRecord(UUID.fromString(SPP));socket.connect();printerName=d.getName()==null?"Bluetooth Printer":d.getName();printerMac=d.getAddress();getPreferences(0).edit().putString("printerName",printerName).putString("printerMac",printerMac).apply();runOnUiThread(()->toast("Printer connected ✓"));}catch(Exception e){runOnUiThread(()->toast("Printer connection failed — pair/turn on printer"));}}).start(); }

    void printMemo(Memo m){ if(socket==null||!socket.isConnected()){toast("আগে Bluetooth printer connect করুন");printerScreen();return;} final Memo toPrint=m;new Thread(()->{try{OutputStream out=socket.getOutputStream();out.write(new byte[]{0x1B,0x40});Bitmap b=renderMemo(toPrint);sendRaster(out,b);out.write(new byte[]{0x1B,0x64,0x04});out.flush();runOnUiThread(()->toast("মেমো print হয়েছে ✓"));}catch(Exception e){runOnUiThread(()->toast("Print failed — printer connection check করুন"));}}).start(); }
    void sendRaster(OutputStream out,Bitmap b)throws IOException{int wb=(b.getWidth()+7)/8;int h=b.getHeight();out.write(new byte[]{0x1D,0x76,0x30,0x00,(byte)(wb&255),(byte)((wb>>8)&255),(byte)(h&255),(byte)((h>>8)&255)});byte[] row=new byte[wb];for(int y=0;y<h;y++){Arrays.fill(row,(byte)0);for(int x=0;x<b.getWidth();x++){int col=b.getPixel(x,y);int gray=(Color.red(col)*299+Color.green(col)*587+Color.blue(col)*114)/1000;if(gray<170)row[x>>3]|=(byte)(0x80>>(x&7));}out.write(row);if(y%64==0)out.flush();}}
    Memo sampleTestMemo(){Memo m=new Memo();m.no=0;m.date=memoDate();m.name="TEST";m.address="80mm Bluetooth Printer";m.items.add(new Item("Test Product","২","৫০","১০০"));m.total=100;return m;}

    void settings(){ openScreen("settings"); shell("Settings","পণ্য ও default price",true);ScrollView sv=scroll();LinearLayout c=content(sv);c.addView(section("Default Product Price"));LinearLayout add=card();EditText n=input("পণ্যের নাম");EditText p=input("ডিফল্ট প্রতি পিস দাম");p.setInputType(android.text.InputType.TYPE_CLASS_TEXT);add.addView(n);add.addView(gap(8));add.addView(p);add.addView(gap(8));Button save=action("＋  Save / Update Price");save.setOnClickListener(v->{String name=n.getText().toString().trim();double val=num(p.getText().toString());if(name.isEmpty()||val<=0){toast("পণ্য ও দাম সঠিকভাবে দিন");return;}prices.put(name,val);savePrices();n.setText("");p.setText("");refreshCurrentScreen();});add.addView(save);c.addView(add);c.addView(gap(14));c.addView(section("Saved Prices"));if(prices.isEmpty())c.addView(tv("কোনো default price save করা নেই",14,MUTED));for(String k:new ArrayList<>(prices.keySet())){LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);TextView a=tv(k,15,TEXT);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);TextView b=tv("৳"+bn(formatNumber(prices.get(k))),15,MUTED);b.setGravity(Gravity.RIGHT);Button del=lightAction("Delete");del.setOnClickListener(v->{prices.remove(k);savePrices();refreshCurrentScreen();});r.addView(a,new LinearLayout.LayoutParams(0,dp(50),1));r.addView(b,new LinearLayout.LayoutParams(dp(85),dp(50)));r.addView(del,new LinearLayout.LayoutParams(dp(82),dp(50)));c.addView(r);c.addView(gap(8));}}

    void refreshCurrentScreen(){ restoringScreen=true; renderScreen(currentScreen); restoringScreen=false; }

    void savedMemos(){ openScreen("saved"); shell("Saved Memos","Local history • newest first",true);ScrollView sv=scroll();LinearLayout c=content(sv);if(history.isEmpty()){c.addView(tv("কোনো saved memo নেই",15,MUTED));return;}for(Memo m:history){LinearLayout r=card();TextView h=tv("মেমো নং "+memoLabel(m.no),18,TEXT);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);r.addView(h);r.addView(tv(m.date+"  •  "+(m.name.isEmpty()?"No customer":m.name),13,MUTED));r.addView(tv("পণ্য: "+bn(String.valueOf(m.items.size()))+"   •   মোট: ৳"+bn(formatNumber(m.total)),14,TEXT));
            ImageView thumb=new ImageView(this); thumb.setImageBitmap(renderMemo(m)); thumb.setAdjustViewBounds(true); thumb.setScaleType(ImageView.ScaleType.FIT_CENTER); thumb.setBackgroundColor(WHITE); thumb.setContentDescription("Saved memo preview");
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(260)); tp.setMargins(0,dp(8),0,dp(8)); r.addView(thumb,tp); thumb.setOnClickListener(v->showSaved(m)); r.addView(gap(7));LinearLayout a=new LinearLayout(this);Button view=lightAction("View");view.setOnClickListener(v->showSaved(m));Button print=action("Print");print.setOnClickListener(v->printMemo(m));a.addView(view,new LinearLayout.LayoutParams(0,50,1));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,50,1);pp.setMargins(8,0,0,0);a.addView(print,pp);r.addView(a);c.addView(r);c.addView(gap(10));}}
    void showSaved(Memo m){ImageView image=new ImageView(this);image.setImageBitmap(renderMemo(m));image.setAdjustViewBounds(true);image.setScaleType(ImageView.ScaleType.FIT_CENTER);ScrollView s=new ScrollView(this);s.setPadding(dp(8),dp(8),dp(8),dp(8));s.addView(image);new AlertDialog.Builder(this).setTitle("Memo "+memoLabel(m.no)).setView(s).setNegativeButton("Close",null).setPositiveButton("Print",(d,w)->printMemo(m)).show();}

    String memoDate(){ Calendar c=Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR,1); return new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(c.getTime()); }
    String memoLabel(int n){ return bn(String.format(Locale.US,"%02d",Math.max(0,n))); }

    String bn(String s){StringBuilder b=new StringBuilder();for(char ch:s.toCharArray())b.append(ch>='0'&&ch<='9'?(char)('০'+ch-'0'):ch);return b.toString();}
    String formatNumber(double d){if(Math.abs(d-Math.rint(d))<0.00001)return String.valueOf((long)Math.rint(d));return String.format(Locale.US,"%.2f",d);}
    double num(String s){if(s==null)return 0;s=s.trim();StringBuilder b=new StringBuilder();for(char ch:s.toCharArray()){if(ch>='০'&&ch<='৯')b.append((char)('0'+ch-'০'));else if(ch==','||ch==' '||ch=='৳'){}else b.append(ch);}try{return Double.parseDouble(b.toString());}catch(Exception e){return 0;}}
    double total(){double t=0;for(Item x:items)t+=num(x.amount);return t;}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void loadPrices(){String raw=getPreferences(0).getString("prices","{}");try{JSONObject o=new JSONObject(raw);Iterator<String>it=o.keys();while(it.hasNext()){String k=it.next();prices.put(k,o.getDouble(k));}}catch(Exception ignored){}}
    void savePrices(){try{JSONObject o=new JSONObject();for(String k:prices.keySet())o.put(k,prices.get(k));getPreferences(0).edit().putString("prices",o.toString()).apply();}catch(Exception ignored){}}
    void loadPrinter(){printerName=getPreferences(0).getString("printerName","");printerMac=getPreferences(0).getString("printerMac","");}
    void loadHistory(){String raw=getPreferences(0).getString("history","[]");try{JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Memo m=new Memo();m.no=o.optInt("no");m.date=o.optString("date");m.name=o.optString("name");m.address=o.optString("address");m.total=o.optDouble("total");JSONArray q=o.optJSONArray("items");if(q!=null)for(int j=0;j<q.length();j++){JSONObject x=q.getJSONObject(j);m.items.add(new Item(x.optString("name"),x.optString("qty"),x.optString("price"),x.optString("amount")));}history.add(m);}}catch(Exception ignored){}}
    void saveHistory(){try{JSONArray a=new JSONArray();for(Memo m:history){JSONObject o=new JSONObject();o.put("no",m.no);o.put("date",m.date);o.put("name",m.name);o.put("address",m.address);o.put("total",m.total);JSONArray q=new JSONArray();for(Item x:m.items){JSONObject z=new JSONObject();z.put("name",x.name);z.put("qty",x.qty);z.put("price",x.price);z.put("amount",x.amount);q.put(z);}o.put("items",q);a.put(o);}getPreferences(0).edit().putString("history",a.toString()).apply();}catch(Exception ignored){}}
}
