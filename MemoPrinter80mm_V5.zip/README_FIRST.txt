Memo Printer 80mm V5
====================
This build focuses on Android full-screen/system-bar handling and navigation.
- Content is inset below the status bar and above the navigation bar.
- Android 13+ back dispatcher is supported.
- Hardware/gesture Back returns to the previous app screen instead of unexpectedly closing.
- Keyboard uses resize behavior.
- Existing memo template, Bangla input, calculations, history, Bluetooth SPP and bitmap printing are retained.

GitHub: upload this ZIP as the only project ZIP and use the existing workflow that extracts the ZIP and builds :app:assembleDebug.
