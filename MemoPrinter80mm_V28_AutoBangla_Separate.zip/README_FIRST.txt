MemoPrinter80mm V28

- Manual Memo and Automatic Input are separate home-menu options.
- Automatic Input has its own screen and is not shown inside Manual Memo.
- Automatic Input accepts Customer on first line, optional ঠিকানা:/Address line, then Product-Quantity lines.
- English product/customer names are converted to Bengali phonetic text offline before memo creation.
- Examples: Pata -> পাতা, Rafi -> রাফি, Store -> স্টোর, Rafi Store -> রাফি স্টোর, Pata k -> পাতা কে.
- Saved default product prices are matched against both original English input and converted Bengali name.
- After automatic completion, the normal memo editor opens so the generated memo can still be reviewed/edited before saving/printing.
- Manual Memo remains unchanged and has no Automatic Input button inside it.
- Existing V25/V26/V27 features remain: editable date, discount, saved-memo mark/print/delete, 80mm print fit, signature safety tail, preview/live preview, Bangla bitmap printing.
