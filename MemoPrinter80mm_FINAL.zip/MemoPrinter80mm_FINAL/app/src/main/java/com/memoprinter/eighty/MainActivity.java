package com.memoprinter.eighty;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int BLUE=Color.rgb(37,99,235), TEXT=Color.rgb(25,35,55), MUTED=Color.rgb(100,116,139), BG=Color.rgb(247,249,252), WHITE=Color.WHITE;
    static final String SPP="00001101-0000-1000-8000-00805F9B34FB";
    final ArrayList<Item> items=new ArrayList<>();
    final LinkedHashMap<String,Double> prices=new LinkedHashMap<>();
    final ArrayList<Memo> history=new ArrayList<>();
    BluetoothAdapter bt; BluetoothSocket socket; String printerName=""; String printerMac="";
    int memoNo=1525;
    EditText customer,address; TextView totalView; Switch autoPrint; LinearLayout productList;
    LinearLayout root; Memo currentMemo;

    static class Item { String name, qty, amount, price; Item(String n,String q,String p,String a){name=n;qty=q;price=p;amount=a;} }
    static class Memo { int no; String date,name,address; ArrayList<Item> items=new ArrayList<>(); double total; }

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        memoNo=getPreferences(0).getInt("memo",1525); loadPrices(); loadHistory(); loadPrinter(); home();
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},10);
    }

    TextView text(String s,float sp,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g; }
    View space(int h){ Space s=new Space(this); s.setLayoutParams(new LinearLayout.LayoutParams(1,h)); return s; }
    Button button(String label){ Button b=new Button(this); b.setText(label); b.setTextSize(14); b.setTextColor(WHITE); b.setAllCaps(false); b.setBackground(bg(BLUE,22)); b.setPadding(20,8,20,8); return b; }
    EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16); e.setSingleLine(false); e.setPadding(16,12,16,12); e.setBackground(bg(WHITE,18)); e.setTextColor(TEXT); e.setHintTextColor(MUTED); return e; }
    void base(String title,String subtitle,boolean back){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(16,10,16,10); bar.setBackgroundColor(WHITE);
        if(back){ TextView x=text("‹",36,TEXT); x.setGravity(Gravity.CENTER); bar.addView(x,new LinearLayout.LayoutParams(48,60)); x.setOnClickListener(v->home()); }
        LinearLayout tt=new LinearLayout(this); tt.setOrientation(LinearLayout.VERTICAL); TextView a=text(title,21,TEXT); TextView c=text(subtitle,12,MUTED); tt.addView(a); tt.addView(c); bar.addView(tt,new LinearLayout.LayoutParams(0,60,1));
        root.addView(bar); setContentView(root);
    }
    ScrollView scroll(){ ScrollView s=new ScrollView(this); s.setFillViewport(true); LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(18,18,18,28); s.addView(c); root.addView(s,new LinearLayout.LayoutParams(-1,0,1)); return s; }
    LinearLayout content(ScrollView s){ return (LinearLayout)s.getChildAt(0); }
    TextView section(String s){ TextView t=text(s,15,TEXT); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(4,14,4,8); return t; }
    LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(18,16,18,16); c.setBackground(bg(WHITE,24)); return c; }

    void home(){ base("Memo Printer 80mm","Bluetooth Thermal Printer • 80mm",false); ScrollView sv=scroll(); LinearLayout c=content(sv);
        LinearLayout hero=card(); hero.setBackground(bg(BLUE,26)); TextView h=text("মেমো টাইপ করে\nঅটো প্রিন্ট করুন",25,WHITE); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); hero.addView(h); TextView sub=text("বাংলা মেমো • অটো হিসাব • 80mm bitmap print",14,0xFFE5EDFF); hero.addView(sub); c.addView(hero); c.addView(space(14));
        LinearLayout row1=new LinearLayout(this); row1.setWeightSum(2); addHomeCard(row1,"🧾","মেমো তৈরি করুন","নতুন অর্ডার মেমো",v->newMemo()); addHomeCard(row1,"📚","Saved Memos","পুরনো মেমো দেখুন",v->savedMemos()); c.addView(row1); c.addView(space(12));
        LinearLayout row2=new LinearLayout(this); row2.setWeightSum(2); addHomeCard(row2,"🖨","Bluetooth","Printer connect করুন",v->printerScreen()); addHomeCard(row2,"⚙","Settings","পণ্য ও ডিফল্ট দাম",v->settings()); c.addView(row2); c.addView(space(14));
        LinearLayout info=card(); info.addView(text("✓ বাংলা সংখ্যা সাপোর্ট\n✓ 100% memo-template based preview\n✓ ESC/POS raster bitmap printing\n✓ Product default price + auto total",14,TEXT)); c.addView(info);
    }
    void addHomeCard(LinearLayout row,String icon,String title,String sub,View.OnClickListener l){ LinearLayout c=card(); c.setOnClickListener(l); TextView i=text(icon,27,TEXT); c.addView(i); TextView a=text(title,17,TEXT); a.setTypeface(Typeface.DEFAULT,Typeface.BOLD); c.addView(a); c.addView(text(sub,12,MUTED)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,145,1); p.setMargins(0,0,6,0); row.addView(c,p); }

    void newMemo(){ items.clear(); currentMemo=null; base("মেমো তৈরি করুন","নতুন অর্ডার • মেমো নং "+bn(String.valueOf(memoNo)),true); ScrollView sv=scroll(); LinearLayout c=content(sv);
        LinearLayout top=card();
        customer=input("কাস্টমারের নাম"); address=input("ঠিকানা"); address.setMinLines(2); top.addView(section("Customer Information")); top.addView(customer); top.addView(space(8)); top.addView(address); c.addView(top); c.addView(space(12));
        LinearLayout prod=card(); prod.addView(section("পণ্য তালিকা")); productList=new LinearLayout(this); productList.setOrientation(LinearLayout.VERTICAL); prod.addView(productList); Button add=button("＋  পণ্য যোগ করুন"); add.setOnClickListener(v->addProductDialog()); prod.addView(space(10)); prod.addView(add); c.addView(prod); c.addView(space(12));
        LinearLayout totalCard=card(); totalView=text("মোট টাকা: ৳০",21,TEXT); totalView.setGravity(Gravity.RIGHT); totalCard.addView(totalView); autoPrint=new Switch(this); autoPrint.setText("Auto Print"); autoPrint.setTextSize(15); autoPrint.setTextColor(TEXT); totalCard.addView(autoPrint); c.addView(totalCard); c.addView(space(12));
        LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.CENTER_VERTICAL); Button preview=button("👁  Preview"); preview.setOnClickListener(v->previewMemo()); Button save=button("💾  Save Memo"); save.setOnClickListener(v->saveAndMaybePrint()); actions.addView(preview,new LinearLayout.LayoutParams(0,54,1)); LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,54,1); q.setMargins(8,0,0,0); actions.addView(save,q); c.addView(actions); refreshProducts();
    }

    void addProductDialog(){ final LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(24,5,24,5);
        final EditText n=input("পণ্য নাম"); final EditText q=input("পরিমাণ (যেমন ২ বা 2)"); final EditText p=input("প্রতি পিস দাম (যেমন ২৫ বা 25)"); q.setInputType(android.text.InputType.TYPE_CLASS_TEXT); p.setInputType(android.text.InputType.TYPE_CLASS_TEXT); l.addView(n); l.addView(space(8)); l.addView(q); l.addView(space(8)); l.addView(p); l.addView(space(8)); TextView calc=text("টাকা: ৳০",16,BLUE); l.addView(calc);
        n.setOnFocusChangeListener((v,has)->{if(!has){Double d=prices.get(n.getText().toString().trim()); if(d!=null)p.setText(bn(formatNumber(d))); updateCalc(q,p,calc);}}); q.addTextChangedListener(watcher(q,p,calc)); p.addTextChangedListener(watcher(q,p,calc));
        new AlertDialog.Builder(this).setTitle("পণ্য যোগ করুন").setView(l).setPositiveButton("যোগ করুন",(d,w)->{ String name=n.getText().toString().trim(); if(name.isEmpty()){toast("পণ্যের নাম দিন");return;} double qty=num(q.getText().toString()), price=num(p.getText().toString()); if(qty<=0){toast("পরিমাণ সঠিকভাবে দিন");return;} if(price<=0 && prices.containsKey(name)) price=prices.get(name); items.add(new Item(name,bn(formatNumber(qty)),bn(formatNumber(price)),bn(formatNumber(qty*price)))); refreshProducts(); }).setNegativeButton("বাতিল",null).show();
    }
    android.text.TextWatcher watcher(EditText q,EditText p,TextView c){ return new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int d){} public void onTextChanged(CharSequence s,int a,int b,int d){updateCalc(q,p,c);} public void afterTextChanged(android.text.Editable e){}}; }
    void updateCalc(EditText q,EditText p,TextView c){ c.setText("টাকা: ৳"+bn(formatNumber(num(q.getText().toString())*num(p.getText().toString())))); }
    void refreshProducts(){ if(productList==null)return; productList.removeAllViews(); if(items.isEmpty()){ TextView e=text("এখনও কোনো পণ্য যোগ করা হয়নি",14,MUTED); e.setPadding(8,18,8,18); productList.addView(e); }
        double total=0; for(int i=0;i<items.size();i++){ Item x=items.get(i); total+=num(x.amount); LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(8,8,4,8); LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); TextView a=text(x.name,15,TEXT); a.setTypeface(Typeface.DEFAULT,Typeface.BOLD); info.addView(a); info.addView(text("পরিমাণ: "+x.qty+"   •   প্রতি পিস: ৳"+x.price,12,MUTED)); TextView am=text("৳"+x.amount,15,TEXT); am.setGravity(Gravity.RIGHT); r.addView(info,new LinearLayout.LayoutParams(0,60,1)); r.addView(am,new LinearLayout.LayoutParams(90,60)); TextView del=text("×",28,0xFFEF4444); del.setGravity(Gravity.CENTER); int idx=i; del.setOnClickListener(v->{items.remove(idx);refreshProducts();}); r.addView(del,new LinearLayout.LayoutParams(38,60)); productList.addView(r); if(i<items.size()-1)productList.addView(space(1)); }
        if(totalView!=null)totalView.setText("মোট টাকা: ৳"+bn(formatNumber(total)));
    }

    void previewMemo(){ if(items.isEmpty()){toast("কমপক্ষে একটি পণ্য যোগ করুন");return;} Memo m=readMemo(); final ImageView image=new ImageView(this); image.setImageBitmap(renderMemo(m)); image.setAdjustViewBounds(true); image.setBackgroundColor(WHITE); ScrollView s=new ScrollView(this); s.addView(image); new AlertDialog.Builder(this).setTitle("Print Preview • 80mm").setView(s).setNegativeButton("Close",null).setPositiveButton("🖨 Print",(d,w)->printMemo(m)).show(); }
    void saveAndMaybePrint(){ if(items.isEmpty()){toast("কমপক্ষে একটি পণ্য যোগ করুন");return;} Memo m=readMemo(); persistMemo(m); if(autoPrint!=null && autoPrint.isChecked()) printMemo(m); else toast("মেমো সেভ হয়েছে ✓"); }
    Memo readMemo(){ Memo m=new Memo(); m.no=memoNo; m.date=new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date()); m.name=customer.getText().toString().trim(); m.address=address.getText().toString().trim(); for(Item x:items)m.items.add(new Item(x.name,x.qty,x.price,x.amount)); m.total=total(); return m; }
    void saveMemo(Memo m){ history.removeIf(x->x.no==m.no); history.add(0,m); saveHistory(); currentMemo=m; }
    void persistMemo(Memo m){
        boolean isNewCurrent = (m.no == memoNo);
        saveMemo(m);
        if(isNewCurrent){
            getPreferences(0).edit().putInt("memo",memoNo+1).apply();
            memoNo++;
        }
    }

    Bitmap renderMemo(Memo m){ Bitmap src=BitmapFactory.decodeResource(getResources(),getResources().getIdentifier("memo_template","drawable",getPackageName())); int w=576; float scale=w/(float)src.getWidth(); int h=Math.round(src.getHeight()*scale); Bitmap b=Bitmap.createScaledBitmap(src,w,h,true).copy(Bitmap.Config.ARGB_8888,true); Canvas c=new Canvas(b); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK); p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        // Coordinates are based on the supplied 582px-wide handwritten memo template.
        float sx=scale; p.setTextSize(22*sx); draw(c,p,bn(Integer.toString(m.no)),260*sx,157*sx,Paint.Align.CENTER);
        p.setTextSize(20*sx); draw(c,p,bn(m.date),482*sx,157*sx,Paint.Align.CENTER);
        p.setTextSize(21*sx); draw(c,p,m.name,95*sx,219*sx,Paint.Align.LEFT); draw(c,p,m.address,95*sx,282*sx,Paint.Align.LEFT);
        p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); p.setTextSize(19*sx); float[] rows={405,466,527,587,647,707,768,828,889,949,1010};
        for(int i=0;i<m.items.size() && i<rows.length;i++){Item x=m.items.get(i); float y=rows[i]*sx; p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL)); p.setTextSize(17*sx); draw(c,p,fit(x.name,260*sx,p),18*sx,y,Paint.Align.LEFT); draw(c,p,fit(x.qty,70*sx,p),352*sx,y,Paint.Align.CENTER); draw(c,p,fit("৳"+x.amount,150*sx,p),486*sx,y,Paint.Align.CENTER);}
        p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); p.setTextSize(21*sx); draw(c,p,"মোট: ৳"+bn(formatNumber(m.total)),288*sx,1092*sx,Paint.Align.CENTER); return b;
    }
    void draw(Canvas c,Paint p,String s,float x,float y,Paint.Align align){p.setTextAlign(align); c.drawText(s,x,y,p);} 
    String fit(String s,float max,Paint p){ if(p.measureText(s)<=max)return s; String z=s; while(z.length()>1 && p.measureText(z+"…")>max)z=z.substring(0,z.length()-1); return z+"…"; }

    void printerScreen(){ base("Bluetooth Printer","80mm ESC/POS • Classic SPP",true); ScrollView sv=scroll(); LinearLayout c=content(sv); LinearLayout card=card(); card.addView(text("Connected printer",14,MUTED)); TextView status=text(printerName.isEmpty()?"কোনো printer connect করা নেই":printerName,19,TEXT); status.setTypeface(Typeface.DEFAULT,Typeface.BOLD); card.addView(status); if(!printerMac.isEmpty())card.addView(text(printerMac,12,MUTED)); c.addView(card); c.addView(space(12)); Button choose=button("🔵  Paired Bluetooth Printers"); choose.setOnClickListener(v->choosePrinter()); c.addView(choose); c.addView(space(10)); Button test=button("🖨  Test Print"); test.setOnClickListener(v->{Memo m=sampleTestMemo();printMemo(m);}); c.addView(test); }
    void choosePrinter(){ if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},11);return;} bt=BluetoothAdapter.getDefaultAdapter(); if(bt==null){toast("এই ফোনে Bluetooth নেই");return;} if(!bt.isEnabled()){toast("আগে Bluetooth চালু করুন");return;} ArrayList<BluetoothDevice> ds=new ArrayList<>(bt.getBondedDevices()); if(ds.isEmpty()){toast("Phone settings থেকে printer pair করুন");return;} String[] names=new String[ds.size()]; for(int i=0;i<ds.size();i++)names[i]=ds.get(i).getName()+"\n"+ds.get(i).getAddress(); new AlertDialog.Builder(this).setTitle("Paired Printers").setItems(names,(d,w)->connect(ds.get(w))).show(); }
    void connect(BluetoothDevice d){ try{ if(socket!=null)socket.close(); socket=d.createRfcommSocketToServiceRecord(UUID.fromString(SPP)); socket.connect(); printerName=d.getName(); printerMac=d.getAddress(); getPreferences(0).edit().putString("printerName",printerName).putString("printerMac",printerMac).apply(); toast("Printer connected ✓"); }catch(Exception e){toast("Printer connection failed");} }

    void printMemo(Memo m){ if(socket==null || !socket.isConnected()){toast("আগে Bluetooth printer connect করুন"); printerScreen(); choosePrinter(); return;} try{ OutputStream out=socket.getOutputStream(); out.write(new byte[]{0x1B,0x40}); Bitmap b=renderMemo(m); sendRaster(out,b); out.write(new byte[]{0x1B,0x64,0x04}); out.flush(); persistMemo(m); toast("মেমো print হয়েছে ✓"); }catch(Exception e){toast("Print failed — printer connection check করুন");} }
    void sendRaster(OutputStream out,Bitmap b)throws IOException{ int widthBytes=(b.getWidth()+7)/8; int height=b.getHeight(); byte[] header=new byte[]{0x1D,0x76,0x30,0x00,(byte)(widthBytes&255),(byte)((widthBytes>>8)&255),(byte)(height&255),(byte)((height>>8)&255)}; out.write(header); byte[] row=new byte[widthBytes]; for(int y=0;y<height;y++){Arrays.fill(row,(byte)0); for(int x=0;x<b.getWidth();x++){int col=b.getPixel(x,y); int r=Color.red(col),g=Color.green(col),bl=Color.blue(col); int gray=(r*299+g*587+bl*114)/1000; if(gray<180)row[x>>3]|=(byte)(0x80>>(x&7));} out.write(row); if(y%32==0)out.flush();} }
    Memo sampleTestMemo(){Memo m=new Memo();m.no=0;m.date=new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date());m.name="TEST";m.address="80mm Bluetooth Printer";m.items.add(new Item("Test Product","২","৫০","১০০"));m.total=100;return m;}

    void settings(){ base("Settings","Products & default prices",true); ScrollView sv=scroll(); LinearLayout c=content(sv); c.addView(section("Default Product Prices")); LinearLayout add=card(); EditText n=input("পণ্য নাম"); EditText p=input("ডিফল্ট প্রতি পিস দাম"); p.setInputType(android.text.InputType.TYPE_CLASS_TEXT); add.addView(n);add.addView(space(8));add.addView(p);Button save=button("＋  Save / Update Price");save.setOnClickListener(v->{String name=n.getText().toString().trim();double val=num(p.getText().toString());if(name.isEmpty()||val<=0){toast("পণ্য ও দাম সঠিকভাবে দিন");return;}prices.put(name,val);savePrices();n.setText("");p.setText("");showPrices(c);});add.addView(space(8));add.addView(save);c.addView(add);c.addView(space(12));showPrices(c); }
    void showPrices(LinearLayout c){ TextView title=section("Saved Prices"); c.addView(title); LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL); for(String k:prices.keySet()){LinearLayout r=card();r.setPadding(14,10,14,10);TextView a=text(k,15,TEXT);TextView b=text("৳"+bn(formatNumber(prices.get(k))),15,MUTED);r.addView(a);r.addView(b);Button del=button("Delete");del.setOnClickListener(v->{prices.remove(k);savePrices();settings();});r.addView(del);list.addView(r);c.addView(list); } }

    void savedMemos(){ base("Saved Memos","Local history • newest first",true); ScrollView sv=scroll();LinearLayout c=content(sv);if(history.isEmpty()){c.addView(text("কোনো saved memo নেই",16,MUTED));return;}for(Memo m:history){LinearLayout card=card();TextView h=text("মেমো নং "+bn(Integer.toString(m.no)),18,TEXT);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);card.addView(h);card.addView(text(m.date+"  •  "+(m.name.isEmpty()?"No customer":m.name),13,MUTED));card.addView(text("পণ্য: "+m.items.size()+"   •   মোট: ৳"+bn(formatNumber(m.total)),14,TEXT));LinearLayout a=new LinearLayout(this);Button view=button("View");view.setOnClickListener(v->showSaved(m));Button print=button("Print");print.setOnClickListener(v->printMemo(m));a.addView(view,new LinearLayout.LayoutParams(0,50,1));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,50,1);pp.setMargins(8,0,0,0);a.addView(print,pp);card.addView(space(8));card.addView(a);c.addView(card);c.addView(space(10));}}
    void showSaved(Memo m){ImageView image=new ImageView(this);image.setImageBitmap(renderMemo(m));image.setAdjustViewBounds(true);ScrollView s=new ScrollView(this);s.addView(image);new AlertDialog.Builder(this).setTitle("Memo "+bn(Integer.toString(m.no))).setView(s).setNegativeButton("Close",null).setPositiveButton("Print",(d,w)->printMemo(m)).show();}

    String bn(String s){StringBuilder b=new StringBuilder();for(char ch:s.toCharArray()){if(ch>='0'&&ch<='9')b.append((char)('০'+ch-'0'));else b.append(ch);}return b.toString();}
    String formatNumber(double d){ if(Math.abs(d-Math.rint(d))<0.00001)return String.valueOf((long)Math.rint(d));return String.format(Locale.US,"%.2f",d); }
    double num(String s){if(s==null)return 0;s=s.trim();StringBuilder b=new StringBuilder();for(char ch:s.toCharArray()){if(ch>='০'&&ch<='৯')b.append((char)('0'+ch-'০'));else if(ch==','||ch==' '||ch=='৳'){}else b.append(ch);}try{return Double.parseDouble(b.toString());}catch(Exception e){return 0;}}
    double total(){double t=0;for(Item x:items)t+=num(x.amount);return t;}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void loadPrices(){String raw=getPreferences(0).getString("prices","{}");try{JSONObject o=new JSONObject(raw);Iterator<String> it=o.keys();while(it.hasNext()){String k=it.next();prices.put(k,o.getDouble(k));}}catch(Exception ignored){}}
    void savePrices(){try{JSONObject o=new JSONObject();for(String k:prices.keySet())o.put(k,prices.get(k));getPreferences(0).edit().putString("prices",o.toString()).apply();}catch(Exception ignored){}}
    void loadPrinter(){printerName=getPreferences(0).getString("printerName","");printerMac=getPreferences(0).getString("printerMac","");}
    void loadHistory(){String raw=getPreferences(0).getString("history","[]");try{JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Memo m=new Memo();m.no=o.optInt("no");m.date=o.optString("date");m.name=o.optString("name");m.address=o.optString("address");m.total=o.optDouble("total");JSONArray q=o.optJSONArray("items");if(q!=null)for(int j=0;j<q.length();j++){JSONObject x=q.getJSONObject(j);m.items.add(new Item(x.optString("name"),x.optString("qty"),x.optString("price"),x.optString("amount")));}history.add(m);}}catch(Exception ignored){}}
    void saveHistory(){try{JSONArray a=new JSONArray();for(Memo m:history){JSONObject o=new JSONObject();o.put("no",m.no);o.put("date",m.date);o.put("name",m.name);o.put("address",m.address);o.put("total",m.total);JSONArray q=new JSONArray();for(Item x:m.items){JSONObject z=new JSONObject();z.put("name",x.name);z.put("qty",x.qty);z.put("price",x.price);z.put("amount",x.amount);q.put(z);}o.put("items",q);a.put(o);}getPreferences(0).edit().putString("history",a.toString()).apply();}catch(Exception ignored){}}
}
