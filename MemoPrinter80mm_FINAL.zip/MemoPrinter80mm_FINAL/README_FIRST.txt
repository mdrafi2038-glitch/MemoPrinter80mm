MEMO PRINTER 80MM - FINAL BUILD PACKAGE

IMPORTANT:
1. Create a NEW GitHub repository named MemoPrinter80mm (do NOT name the repository .zip).
2. Upload this ZIP file to the repository root.
3. Create .github/workflows/build-apk.yml in GitHub (the workflow code is supplied in ChatGPT instructions).
4. Run Actions -> Build Memo Printer APK -> Run workflow.
5. Download the artifact named MemoPrinter80mm-APK and install app-debug.apk.

The project uses the supplied 582x1280 memo template, Bangla-number input, default product prices, automatic quantity x price calculation, saved memo history, Bluetooth Classic SPP and bitmap ESC/POS printing.
