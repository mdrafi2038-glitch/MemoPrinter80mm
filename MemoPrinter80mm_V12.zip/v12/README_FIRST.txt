MemoPrinter80mm V12

Fixes in this version:
- Live Preview is regenerated immediately after customer/address/product changes.
- Saved Memos now show an actual memo thumbnail, and View opens the exact saved snapshot.
- Save stores the current memo data before any print action.
- Preview uses the same renderMemo bitmap used for printing.
- Memo numbering starts at 01 and memo date is tomorrow.
