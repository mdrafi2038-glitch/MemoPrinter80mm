Memo Printer 80mm - V23

V23 adds a discount amount field to New Memo. Save Memo and Preview buttons are smaller, with Discount between them. The discount is applied to the subtotal and printed as a separate line immediately before the final total, e.g. "ছাড়: -৳৫০০" followed by "মোট: ৳৪৯,৫০০". Saved memos persist subtotal, discount and final total. Print/preview use the same renderer.
