Memo Printer 80mm - V10

This version fixes UI sizing/insets and adds a real always-visible LIVE PREVIEW on the New Memo screen.
- Layout dimensions are density-independent (dp), not raw pixels.
- Status bar / notch safe area is applied to the toolbar.
- Navigation bar safe area is respected.
- Home dashboard uses weighted rows to fill the available viewport.
- New Memo shows an always-on live 80mm preview below the form.
- Customer/address typing and product add/edit/delete immediately refresh the preview.
- Tapping the live preview opens a larger Preview dialog.
- Memo numbers start at 01; memo date is tomorrow.
