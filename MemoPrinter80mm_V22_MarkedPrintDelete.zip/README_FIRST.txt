Memo Printer 80mm - V18

This version focuses on readable memo text:
- Larger, bolder Memo No and Date, positioned near the original header line.
- Larger Customer and Address text.
- Larger, bold Product Name / Quantity / Amount text.
- Larger Total text.
- Original 80mm memo template retained.
- Preview, Live Preview, Saved Memo View and Print use the same renderer.
- Bengali fonts bundled in assets.

V20 print-size fix:
- Memo raster width changed from 576 dots to 640 dots for 80mm thermal printers.
- This makes the entire memo use more of the printable 80mm width instead of appearing undersized.
- Preview/live preview/saved memo use the same 640-dot renderer.
- Text remains at 34 logical source units and scales with the 640-dot render.
