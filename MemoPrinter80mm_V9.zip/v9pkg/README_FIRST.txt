MemoPrinter80mm V9

This version fixes top header/status-bar overlap on modern Android phones, including Android 15 edge-to-edge behavior.

Safe-area changes:
- Uses AndroidX WindowInsetsCompat + display cutout insets.
- Draws edge-to-edge only while explicitly padding the root content below system bars.
- Transparent system bars with dark status-bar icons.
- Header height increased so titles and back buttons remain fully visible.
- Bottom system/gesture area is also protected.

Other app features are preserved from V8.
