MemoPrinter80mm v3.0

This package is a root Android Studio/Gradle project.
Features:
- modern blue/white memo UI
- Bangla/English quantity and price input
- saved default product prices
- quantity x price auto calculation
- automatic total
- memo number starts at 1525 and increments for new memos
- original 80mm memo image is used as the print/preview template
- bitmap ESC/POS printing for Bangla
- Bluetooth Classic SPP printer connection
- saved memo history
- product edit/delete
- preview and Auto Print

Build with Gradle 8.7 + Java 17 (e.g. GitHub Actions).
