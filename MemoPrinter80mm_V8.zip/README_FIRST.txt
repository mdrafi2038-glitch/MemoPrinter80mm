MemoPrinter80mm V6

Fixes:
- Dashboard content now fills the available screen height instead of clustering at the top.
- ScrollView child uses MATCH_PARENT with fillViewport.
- Flexible bottom space keeps the dashboard vertically balanced on tall screens while remaining scrollable.
- Existing memo, Bangla input, calculation, history, Bluetooth SPP and bitmap printing features retained.

GitHub: upload this ZIP as the only project ZIP and use the existing workflow.
