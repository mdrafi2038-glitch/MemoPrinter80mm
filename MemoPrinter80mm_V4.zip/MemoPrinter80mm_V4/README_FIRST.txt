MemoPrinter80mm V4

This version specifically fixes:
- Full-screen/system-bar overlap by using proper window fitting and resize behavior.
- Back button navigation: Back returns to the previous app screen instead of immediately closing the app.
- Header back button follows the same navigation stack.
- Keyboard uses resize behavior so fields remain accessible.

Preserved features:
- Original 80mm memo template bitmap
- Bangla/English quantity and price input
- Quantity × default price calculation
- Memo numbering starting at 1525
- Date, customer name and address
- Product edit/delete
- Preview and bitmap ESC/POS printing
- Bluetooth Classic SPP
- Saved memo history
- Auto Print
