Memo Printer 80mm — V15 Preview Checked

- Original 80mm memo template is retained.
- Bangla renderer uses bundled Noto Sans Bengali fonts from app/src/main/assets.
- Preview button renders the exact same bitmap used for printing.
- Live Preview updates when customer/address/products change.
- Saved Memo thumbnails and View use the same renderer.
- Memo number starts at 01 on a fresh install and increments after Save.
- Memo date is tomorrow's date.
- Quantity x price calculates amount and total.
- Returning to the New Memo screen no longer clears the current products.
- Preview rendering errors are no longer silently hidden.

Build with the existing GitHub workflow.
